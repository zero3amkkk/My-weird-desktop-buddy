@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo === My Weird Desktop Buddy - Release build ===
where dotnet >nul 2>nul
if errorlevel 1 (
  echo.
  echo [X] .NET 8 SDK مش متسطب على الجهاز ده.
  echo     نزّله من: https://dotnet.microsoft.com/download/dotnet/8.0  ^(SDK x64^)
  echo     او استخدم GitHub Actions - شوف README.md
  pause & exit /b 1
)
if exist dist rmdir /s /q dist
dotnet publish MyWeirdDesktopBuddy.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o dist
if errorlevel 1 ( echo [X] البناء فشل & pause & exit /b 1 )
copy /y dist_extras\*.bat dist\ >nul
copy /y README.md dist\ >nul
powershell -NoProfile -Command "Compress-Archive -Path 'dist\*' -DestinationPath 'MyWeirdDesktopBuddy_Portable.zip' -Force"
echo.
echo [OK] الملف جاهز: dist\MyWeirdDesktopBuddy.exe
echo [OK] نسخة Portable: MyWeirdDesktopBuddy_Portable.zip
pause
