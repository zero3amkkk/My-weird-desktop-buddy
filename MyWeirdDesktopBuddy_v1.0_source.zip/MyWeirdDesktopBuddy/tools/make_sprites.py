# Generates every sprite sheet (48x48 frames, facing right) for My Weird Desktop Buddy.
# Run:  python make_sprites.py   (needs Pillow + numpy). Output goes to ../Assets
import os, math
import numpy as np
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.normpath(os.path.join(HERE, "..", "Assets"))
os.makedirs(OUT, exist_ok=True)
C = 48

SKIN=(198,142,102); SKIN_D=(160,104,72)
HAIR=(26,22,30); HAIR_L=(60,54,68)
RED=(168,38,46); RED_D=(112,22,34); SLEEVE=(196,60,64)
JEAN=(52,80,132); JEAN_D=(36,58,100)
SHOE=(238,238,244); SHOE_D=(150,152,168)
WHITE=(252,252,252); INK=(24,16,26); EYE=(22,16,24); MOUTH=(112,48,56)
BROWN=(160,106,62); BROWN_L=(190,136,84); BROWN_D=(112,72,44)
BLUE=(62,110,210); BLUE_D=(36,64,140); YELLOW=(255,214,64)
GREEN=(46,140,66); BEZEL=(58,60,72)

def R(d,x0,y0,x1,y1,c): d.rectangle([x0,y0,x1,y1],fill=tuple(c)+(255,))
def P(d,x,y,c): d.point((x,y),fill=tuple(c)+(255,))

def leg(d,hip,foot):
    d.line([hip,foot],fill=JEAN+(255,),width=4)
    fx,fy=foot
    R(d,fx-2,fy+1,fx+3,fy+2,SHOE); R(d,fx-2,fy+2,fx+3,fy+2,SHOE_D)

def legs_std(by=0,ll=0,lr=0,dxl=0,dxr=0):
    return (((21,38+by),(21+dxl,44-ll)),((26,38+by),(26+dxr,44-lr)))

def eyes_draw(d,ox,ey,kind,pup):
    for i,x in enumerate((22+ox,27+ox)):
        if kind in ('open','look'):
            R(d,x+pup,ey,x+pup+1,ey+1,EYE); R(d,x,ey-2,x+2,ey-2,HAIR)
        elif kind in ('blink','closed'):
            R(d,x,ey+1,x+1,ey+1,EYE); R(d,x,ey-2,x+2,ey-2,HAIR)
        elif kind=='wide':
            R(d,x-1,ey-1,x+2,ey+2,WHITE); R(d,x+pup,ey,x+pup+1,ey+1,EYE); R(d,x-1,ey-3,x+2,ey-3,HAIR)
        elif kind=='angry':
            R(d,x,ey,x+1,ey+1,EYE)
            pts=[(x,ey-3),(x+1,ey-2),(x+2,ey-2)] if i==0 else [(x+2,ey-3),(x+1,ey-2),(x,ey-2)]
            for p in pts: P(d,p[0],p[1],HAIR)
        elif kind=='tired':
            R(d,x,ey,x+1,ey,SKIN_D); R(d,x,ey+1,x+1,ey+1,EYE); R(d,x,ey+2,x+1,ey+2,SKIN_D); R(d,x,ey-2,x+2,ey-2,HAIR)
        elif kind=='dizzy':
            for p in [(x-1,ey-1),(x+1,ey-1),(x,ey),(x-1,ey+1),(x+1,ey+1)]: P(d,p[0],p[1],EYE)

def mouth_draw(d,ox,my,kind):
    if kind=='smile':
        for p in [(23,my-1),(24,my),(25,my),(26,my),(27,my-1)]: P(d,p[0]+ox,p[1],MOUTH)
    elif kind=='flat': R(d,23+ox,my,27+ox,my,MOUTH)
    elif kind=='smirk':
        R(d,24+ox,my,27+ox,my,MOUTH); P(d,28+ox,my-1,MOUTH)
    elif kind=='frown':
        for p in [(23,my+1),(24,my),(25,my),(26,my),(27,my+1)]: P(d,p[0]+ox,p[1],MOUTH)
    elif kind=='open':
        R(d,24+ox,my,26+ox,my+2,MOUTH); P(d,25+ox,my+2,SLEEVE)
    elif kind=='o': R(d,25+ox,my,26+ox,my+1,MOUTH)
    elif kind=='yawn': R(d,24+ox,my,27+ox,my+3,MOUTH); P(d,25+ox,my+3,SLEEVE)
    elif kind=='shout':
        R(d,23+ox,my,27+ox,my+2,MOUTH); R(d,24+ox,my,26+ox,my,WHITE)

def char(by=0,hyo=0,ox=0,legs=None,hands=None,eyes='open',mouth='smile',pup=0,sit=False):
    im=Image.new("RGBA",(C,C),(0,0,0,0)); d=ImageDraw.Draw(im)
    if sit:
        R(d,25,42,36,45,JEAN); R(d,25,42,36,42,JEAN_D)
        R(d,37,40,40,45,SHOE); R(d,37,45,40,45,SHOE_D)
    else:
        L,Rr=legs or legs_std()
        leg(d,*L); leg(d,*Rr)
    t0=27+by
    R(d,17+ox,t0,30+ox,t0+11,RED)
    R(d,29+ox,t0,30+ox,t0+11,RED_D)
    R(d,17+ox,t0+10,30+ox,t0+11,RED_D)
    R(d,20+ox,t0+6,27+ox,t0+9,RED_D); R(d,21+ox,t0+7,26+ox,t0+8,RED)
    R(d,18+ox,t0-1,29+ox,t0+1,RED_D); R(d,17+ox,t0-1,18+ox,t0+1,RED); R(d,29+ox,t0-1,30+ox,t0+1,RED)
    for yy in range(t0+2,t0+6): P(d,22+ox,yy,WHITE)
    for yy in range(t0+2,t0+5): P(d,26+ox,yy,WHITE)
    if hands is None:
        hands=((14+ox,37+by),(33+ox,37+by))
    for sh,h in (((16+ox,29+by),hands[0]),((31+ox,29+by),hands[1])):
        d.line([sh,h],fill=SLEEVE+(255,),width=3)
        R(d,h[0]-1,h[1]-1,h[0],h[1],SKIN)
    hy0=13+by+hyo
    R(d,17+ox,hy0+1,18+ox,hy0+6,HAIR); R(d,29+ox,hy0+1,30+ox,hy0+5,HAIR)
    R(d,18+ox,hy0+5,29+ox,hy0+13,SKIN)
    R(d,18+ox,hy0,29+ox,hy0+4,HAIR)
    for x in (19,22,25,28): R(d,x+ox,hy0-1,x+1+ox,hy0-1,HAIR)
    R(d,18+ox,hy0+5,23+ox,hy0+5,HAIR)
    for p in [(20,hy0+1),(24,hy0+2),(27,hy0+1)]: P(d,p[0]+ox,p[1],HAIR_L)
    R(d,17+ox,hy0+8,17+ox,hy0+9,SKIN); R(d,29+ox,hy0+12,29+ox,hy0+13,SKIN_D)
    P(d,27+ox,hy0+10,SKIN_D)
    eyes_draw(d,ox,hy0+8,eyes,pup)
    mouth_draw(d,ox,hy0+11,mouth)
    return im

def desk(d):
    R(d,30,36,47,38,BROWN); R(d,30,36,47,36,BROWN_L); R(d,30,38,47,38,BROWN_D)
    R(d,31,39,32,46,BROWN_D); R(d,45,39,46,46,BROWN_D)

def book_open(d,x=33,y=33):
    R(d,x-1,y+3,x+10,y+3,BLUE_D)
    R(d,x,y,x+4,y+2,WHITE); R(d,x+6,y,x+10,y+2,WHITE); R(d,x+5,y,x+5,y+2,SHOE_D)
    for i in (1,2,3): P(d,x+i,y+1,SHOE_D); P(d,x+6+i,y+1,SHOE_D)

def book_closed(d,x=34,y=33):
    R(d,x,y,x+8,y+3,BLUE); R(d,x,y+3,x+8,y+3,BLUE_D); R(d,x+1,y+1,x+3,y+1,YELLOW)

def over(im,fn):
    d=ImageDraw.Draw(im); fn(d); return im

def hand_pen(im,hx,hy):
    d=ImageDraw.Draw(im); R(d,hx-1,hy-1,hx,hy,SKIN); P(d,hx+1,hy+1,YELLOW); P(d,hx+1,hy+2,SKIN_D)
    return im

def lay(angle,**kw):
    im=char(**kw).rotate(angle,resample=Image.NEAREST,center=(24,30))
    box=im.getbbox(); cr=im.crop(box)
    out=Image.new("RGBA",(C,C),(0,0,0,0)); out.paste(cr,(24-cr.width//2,47-cr.height))
    return out

def tilt(angle,**kw):
    return char(**kw).rotate(angle,resample=Image.NEAREST,center=(24,46))

def zglyph(im,x,y,s=1):
    d=ImageDraw.Draw(im)
    pts=[(0,0),(1,0),(2,0),(3,0),(3,1),(2,2),(1,3),(0,4),(1,4),(2,4),(3,4)]
    for (px,py) in pts:
        if s==1: P(d,x+px,y+py,WHITE)
        else: R(d,x+px*2,y+py*2,x+px*2+1,y+py*2+1,WHITE)
    return im

def stars(im,cx,cy,k):
    d=ImageDraw.Draw(im)
    for i in range(3):
        a=(i*2*math.pi/3)+k*0.9
        x=int(round(cx+9*math.cos(a))); y=int(round(cy+4*math.sin(a)))
        for p in [(x,y),(x-1,y),(x+1,y),(x,y-1),(x,y+1)]: P(d,p[0],p[1],YELLOW)
    return im

A={}
A['idle']=[char(),char(hyo=1),char(),char(eyes='blink')]
A['look']=[char(pup=1,eyes='look'),char(),char(pup=-1,eyes='look')]
A['walk']=[
 char(by=-1,legs=legs_std(by=-1,lr=3,dxr=1),hands=((13,35),(34,37))),
 char(),
 char(by=-1,legs=legs_std(by=-1,ll=3,dxl=-1),hands=((13,37),(34,35))),
 char()]
A['run']=[
 char(by=-1,ox=1,legs=(((21,37),(17,43)),((26,37),(30,40))),hands=((12,33),(35,38)),mouth='open'),
 char(by=-3,ox=1,legs=(((21,35),(20,41)),((26,35),(27,41))),hands=((13,35),(34,35)),mouth='open'),
 char(by=-1,ox=1,legs=(((21,37),(25,40)),((26,37),(22,44))),hands=((12,38),(35,33)),mouth='open'),
 char(by=-3,ox=1,legs=(((21,35),(20,41)),((26,35),(27,41))),hands=((13,35),(34,35)),mouth='open')]
A['jump']=[
 char(by=3,legs=(((21,41),(19,44)),((26,41),(28,44))),hands=((15,40),(32,40)),mouth='flat'),
 char(by=-4,legs=legs_std(by=-4,ll=4,lr=4,dxl=-1,dxr=1),hands=((12,22),(35,22)),eyes='wide',mouth='open'),
 char(by=-2,legs=legs_std(by=-2,ll=2,lr=2),hands=((11,29),(36,29)),eyes='wide',mouth='o')]
SH=((16,43),(33,41))
A['sit']=[char(by=6,sit=True,hands=SH),char(by=6,sit=True,hands=SH,eyes='blink')]
def bored_f(eyes,mouth,hyo):
    return char(by=6,hyo=hyo,sit=True,eyes=eyes,mouth=mouth,hands=((16,43),(29,32)))
A['bored']=[bored_f('tired','frown',0),bored_f('closed','yawn',1)]
def nap(k):
    im=lay(90,eyes='closed',mouth='flat',hands=((14,37),(33,37)))
    zglyph(im,6,24,1)
    if k>=1: zglyph(im,3,16,2)
    return im
A['nap']=[nap(0),nap(1)]
w0=lay(90,eyes='tired',mouth='yawn')
w1=char(by=0,eyes='tired',mouth='yawn').rotate(35,resample=Image.NEAREST,center=(24,46))
w2=char(by=6,sit=True,eyes='tired',mouth='yawn',hands=SH)
A['wake']=[w0,w1,w2]
def study_f(hx,eyes='open'):
    im=char(by=6,hyo=1,sit=True,eyes=eyes,pup=1,hands=((23,40),(hx,32)))
    over(im,desk); over(im,book_open); hand_pen(im,hx,32); return im
A['study']=[study_f(34),study_f(36),study_f(38,'tired'),study_f(36)]
def flip_f(k):
    im=char(by=6,hyo=1,sit=True,pup=1,hands=((23,40),(38,31)))
    over(im,desk); d=ImageDraw.Draw(im)
    book_open(d)
    if k==1: R(d,38,27,39,35,WHITE)
    if k==2: R(d,34,29,37,35,WHITE); P(d,34,28,WHITE)
    hand_pen(im,[38,39,36,38][k],[31,27,28,32][k]); return im
A['flip']=[flip_f(i) for i in range(4)]
def upside(hyo):
    im=char(by=6,hyo=hyo,sit=True,eyes='look',mouth='smirk',pup=1,hands=((29,41),(36,38)))
    d=ImageDraw.Draw(im)
    R(d,28,31,38,41,BLUE_D); R(d,29,32,37,40,BLUE)
    d.polygon([(31,33),(35,33),(33,38)],fill=YELLOW+(255,))
    R(d,30,40,36,40,WHITE)
    R(d,29,41,29,42,SKIN); R(d,36,38,37,39,SKIN)
    return im
A['upside']=[upside(0),upside(1)]
def deskbored(k):
    im=char(by=6,hyo=4 if k==0 else 3,sit=True,eyes='closed' if k==0 else 'tired',mouth='frown' if k==0 else 'yawn',hands=((30,37),(34,35)))
    over(im,desk); over(im,lambda d:book_closed(d,37,33))
    d=ImageDraw.Draw(im); R(d,32,34,33,35,SKIN); R(d,30,36,31,37,SKIN)
    if k==1: P(d,26,17,(120,200,255)); P(d,26,18,(120,200,255))
    return im
A['deskbored']=[deskbored(0),deskbored(1)]
def throw(k):
    if k==0:
        im=char(by=6,sit=True,eyes='angry',mouth='shout',hands=((22,18),(29,18)))
        d=ImageDraw.Draw(im); R(d,20,12,31,16,BLUE); R(d,20,16,31,16,BLUE_D); R(d,22,13,24,13,YELLOW)
    elif k==1:
        im=char(by=6,sit=True,eyes='angry',mouth='shout',hands=((16,43),(37,27)))
        d=ImageDraw.Draw(im); R(d,39,19,46,23,BLUE); R(d,39,23,46,23,BLUE_D)
    elif k==2:
        im=char(by=6,sit=True,eyes='angry',mouth='shout',hands=((16,43),(33,41)))
        d=ImageDraw.Draw(im); R(d,40,31,46,34,BLUE); R(d,40,34,46,34,BLUE_D)
    else:
        im=char(by=6,hyo=2,sit=True,eyes='tired',mouth='flat',hands=((16,43),(33,41)))
        d=ImageDraw.Draw(im); R(d,41,44,46,46,BLUE); R(d,41,46,46,46,BLUE_D)
    return im
A['throw']=[throw(i) for i in range(4)]
def screen(d,k):
    R(d,31,23,47,36,BEZEL); R(d,33,25,45,34,GREEN); R(d,39,25,39,34,WHITE)
    R(d,36,28,42,31,GREEN); P(d,36,28,WHITE);P(d,42,28,WHITE);P(d,36,31,WHITE);P(d,42,31,WHITE)
    R(d,37,37,41,39,BEZEL); R(d,35,39,43,39,BEZEL)
    P(d,34,24,(230,50,50))
    ball=[(35,32),(38,29),(41,31),(43,27)][k]; R(d,ball[0],ball[1],ball[0]+1,ball[1]+1,WHITE)
    pa=[(36,30),(37,31),(38,30),(39,31)][k]; pb=[(42,29),(41,30),(40,29),(41,28)][k]
    P(d,pa[0],pa[1],(230,60,60)); P(d,pb[0],pb[1],(70,120,240))
def watch(k):
    im=char(by=6,sit=True,hands=SH,eyes='look',pup=1,mouth='open' if k in (1,3) else 'smile')
    d=ImageDraw.Draw(im); screen(d,k); return im
A['watch']=[watch(i) for i in range(4)]
A['cheer']=[
 char(hands=((12,20),(35,20)),mouth='open',eyes='wide'),
 char(by=-3,legs=legs_std(by=-3,ll=3,lr=3),hands=((12,16),(35,16)),mouth='open',eyes='wide')]
A['kick']=[
 char(legs=(((21,38),(21,44)),((26,38),(22,41))),hands=((13,35),(34,38)),mouth='flat'),
 char(ox=-1,legs=(((21,38),(20,44)),((26,38),(36,40))),hands=((12,31),(34,34)),mouth='open'),
 char(ox=-1,legs=(((21,38),(20,44)),((26,38),(35,34))),hands=((11,36),(35,30)),mouth='smirk')]
f0=tilt(-40,eyes='wide',mouth='o',hands=((12,20),(35,20)))
f1=lay(-90,eyes='dizzy',mouth='o')
f2=lay(-90,eyes='dizzy',mouth='o')
b1=f1.getbbox(); hx,hy=b1[2]-8,(b1[1]+b1[3])//2-8
stars(f1,hx,hy,0); stars(f2,hx,hy,1)
A['fall']=[f0,f1,f2]
A['held']=[
 char(legs=(((21,38),(19,45)),((26,38),(28,44))),hands=((11,34),(36,41)),eyes='wide',mouth='o'),
 char(legs=(((21,38),(23,44)),((26,38),(25,45))),hands=((13,41),(34,33)),eyes='wide',mouth='o')]
def angry(ox):
    im=char(ox=ox,eyes='angry',mouth='shout',hands=((14+ox,31),(33+ox,31)))
    d=ImageDraw.Draw(im)
    for p in [(32,10),(33,11),(34,10),(33,9),(32,12),(34,12)]: P(d,p[0],p[1],(255,60,60))
    return im
A['angry']=[angry(-1),angry(1)]

def ball_frame(th):
    im=Image.new("RGBA",(16,16),(0,0,0,0)); d=ImageDraw.Draw(im)
    d.ellipse([2,2,13,13],fill=WHITE+(255,),outline=INK+(255,))
    for k in range(3):
        a=math.radians(th+k*120)
        x=int(round(7.5+3.6*math.cos(a))); y=int(round(7.5+3.6*math.sin(a)))
        R(d,x,y,x+1,y+1,INK)
    R(d,7,7,8,8,INK)
    return im

def outline(im):
    a=np.array(im); m=a[...,3]>0
    n=np.zeros_like(m); n[1:]|=m[:-1]; n[:-1]|=m[1:]; n[:,1:]|=m[:,:-1]; n[:,:-1]|=m[:,1:]
    a[n&~m]=[*INK,255]
    return Image.fromarray(a)

FPS={'idle':(3,1),'look':(2,1),'walk':(8,1),'run':(12,1),'jump':(3,0),'sit':(2,1),'bored':(2,1),'nap':(1.5,1),
 'wake':(3,0),'study':(4,1),'flip':(6,0),'upside':(2,1),'deskbored':(2,1),'throw':(5,0),'watch':(3,1),'cheer':(6,1),
 'kick':(8,0),'fall':(3,0),'held':(5,1),'angry':(10,1)}
lines=["# name fps loop"]
for name,frames in A.items():
    sheet=Image.new("RGBA",(C*len(frames),C),(0,0,0,0))
    for i,f in enumerate(frames): sheet.paste(outline(f),(i*C,0))
    sheet.save(os.path.join(OUT,name+".png"))
    lines.append("%s %s %d" % (name,FPS[name][0],FPS[name][1]))
open(os.path.join(OUT,"anims.txt"),"w").write("\n".join(lines)+"\n")

bs=Image.new("RGBA",(64,16),(0,0,0,0))
for i in range(4): bs.paste(ball_frame(i*30),(i*16,0))
bs.save(os.path.join(OUT,"ball.png"))

idle=outline(A['idle'][0]); box=idle.getbbox()
ic=idle.crop((box[0]-2,box[1]-2,box[2]+2,box[3]+2)); s=max(ic.size)
sq=Image.new("RGBA",(s,s),(0,0,0,0)); sq.paste(ic,((s-ic.width)//2,(s-ic.height)//2))
sq=sq.resize((256,256),Image.NEAREST)
sq.save(os.path.join(OUT,"app.ico"),sizes=[(16,16),(32,32),(48,48),(64,64),(128,128),(256,256)])

names=list(A.keys()); maxf=max(len(v) for v in A.values()); S=2
prev=Image.new("RGBA",(maxf*C*S+10,len(names)*(C*S+4)),(120,160,120,255))
for r,name in enumerate(names):
    for i,f in enumerate(A[name]):
        prev.alpha_composite(outline(f).resize((C*S,C*S),Image.NEAREST),(i*C*S,r*(C*S+4)))
prev.save(os.path.join(HERE,"..","preview_sheet.png"))
# bigger hero image of the idle character
hero=Image.new("RGBA",(C*8,C*8),(120,160,120,255)); hero.alpha_composite(outline(A['idle'][0]).resize((C*8,C*8),Image.NEAREST))
hero.save(os.path.join(HERE,"..","preview_character.png"))
print("ok",len(names),"animations")
