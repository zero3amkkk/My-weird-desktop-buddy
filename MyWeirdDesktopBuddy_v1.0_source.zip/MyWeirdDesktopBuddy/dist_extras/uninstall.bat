@echo off
chcp 65001 >nul
echo حذف My Weird Desktop Buddy بالكامل...
taskkill /f /im MyWeirdDesktopBuddy.exe >nul 2>nul
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v MyWeirdDesktopBuddy /f >nul 2>nul
del /f /q "%USERPROFILE%\Desktop\My Weird Desktop Buddy.lnk" >nul 2>nul
rmdir /s /q "%APPDATA%\MyWeirdDesktopBuddy" >nul 2>nul
rmdir /s /q "%LOCALAPPDATA%\MyWeirdDesktopBuddy" >nul 2>nul
echo تم الحذف (الإعدادات + اللوج + التشغيل مع ويندوز + الاختصار).
echo لو شغّلته من فولدر Portable امسح الفولدر ده بإيدك.
pause
