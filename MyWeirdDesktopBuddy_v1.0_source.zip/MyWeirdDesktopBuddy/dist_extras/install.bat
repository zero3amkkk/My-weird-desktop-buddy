@echo off
chcp 65001 >nul
set "DEST=%LOCALAPPDATA%\MyWeirdDesktopBuddy"
echo تثبيت My Weird Desktop Buddy في: %DEST%
taskkill /f /im MyWeirdDesktopBuddy.exe >nul 2>nul
mkdir "%DEST%" >nul 2>nul
copy /y "%~dp0MyWeirdDesktopBuddy.exe" "%DEST%\" >nul
if errorlevel 1 ( echo [X] مش لاقي MyWeirdDesktopBuddy.exe جنب الملف ده & pause & exit /b 1 )
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\My Weird Desktop Buddy.lnk'); $s.TargetPath='%DEST%\MyWeirdDesktopBuddy.exe'; $s.WorkingDirectory='%DEST%'; $s.Save()"
start "" "%DEST%\MyWeirdDesktopBuddy.exe"
echo تم! فيه اختصار على سطح المكتب، والشخصية شغالة دلوقتي.
pause
