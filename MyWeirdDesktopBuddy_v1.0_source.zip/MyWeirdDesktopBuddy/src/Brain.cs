using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace WeirdBuddy
{
    internal enum S { Idle, Look, Walk, Run, Jump, Sit, Bored, Nap, Wake, Study, Flip, Upside, DeskBored, Throw, Watch, Cheer, Chase, Kick, WatchBall, SitBall, Fall, Held, Air, Angry }

    /// <summary>Animation state machine + weighted random behaviour + ball physics. All distances are in "sprite pixels" (spx) x scale.</summary>
    internal sealed class PetBrain
    {
        readonly AppSettings cfg; readonly PetForm view; readonly BallForm ballView; readonly Random rnd = new Random();
        public bool Paused;
        S state; string animName = "idle"; double stateT, stateDur, frameT; int forceFrame = -1;
        double X, Y, vy; int facing = 1; Rectangle area; int scale = 3;
        string bubble; double bubbleLeft; double sinceSay = 99, sinceInteract, sinceProx = 99, areaT, topT;
        bool launched, kicked, dragIgnored; double airStartY; int kicksLeft;
        readonly List<DateTime> clicks = new List<DateTime>();
        bool ballActive, ballSpinning; double bX, bY, bVX, bVY, bAngle, bRest, bSpin, bLife;
        int lastKey = int.MinValue;

        public PetBrain(AppSettings c, PetForm v, BallForm b) { cfg = c; view = v; ballView = b; ballView.Clicked += OnBallClicked; }

        double P(double spx) { return spx * scale; }
        bool CanMove { get { return cfg.AutoMove && !cfg.Pinned; } }
        double Rf { get { return 0.3 + cfg.Randomness / 100.0 * 1.4; } }

        // ---------- lifecycle ----------
        public void Start(int sc)
        {
            scale = sc;
            bool ok = false;
            if (cfg.HasPos)
            {
                foreach (var s in Screen.AllScreens)
                {
                    var wa = s.WorkingArea;
                    if (cfg.PosX >= wa.Left && cfg.PosX <= wa.Right && cfg.PosY > wa.Top && cfg.PosY <= wa.Bottom + 2) { area = wa; X = cfg.PosX; ok = true; break; }
                }
            }
            if (!ok) { area = Screen.PrimaryScreen.WorkingArea; X = area.Right - P(60); }
            Y = area.Bottom; ClampX();
            Enter(S.Idle);
            TrySay(Msg.Greeting, 1.0, true);
            lastKey = int.MinValue; Render();
        }

        public void SetScale(int sc) { scale = sc; lastKey = int.MinValue; ClampX(); }
        public void ForceRedraw() { lastKey = int.MinValue; Render(); }

        public void DebugForce(S s) { Enter(s); }
        public void Greet() { TrySay(Msg.Greeting, 1.0, true); }

        public void Reset() { KillBall(); bubble = null; RefreshArea(); Y = area.Bottom; Enter(S.Idle); }

        public void SetHidden(bool hidden)
        {
            if (hidden) { bubble = null; KillBall(); Persist(); }
            else { lastKey = int.MinValue; sinceInteract = 0; }
        }

        public void HandleDisplayChange()
        {
            KillBall();
            if (state == S.Held || state == S.Air) { Enter(S.Idle); }
            RefreshArea(); Y = area.Bottom; ClampX(); lastKey = int.MinValue;
        }

        public void Persist() { cfg.PosX = (int)X; cfg.PosY = (int)Y; cfg.HasPos = true; cfg.Save(); }

        void RefreshArea()
        {
            try { area = Screen.FromPoint(new Point((int)X, (int)Y - 1)).WorkingArea; }
            catch { area = Screen.PrimaryScreen.WorkingArea; }
        }

        void ClampX()
        {
            if (state == S.Held) return;
            double m = P(16);
            if (area.Width < m * 2) return;
            X = Math.Max(area.Left + m, Math.Min(area.Right - m, X));
        }

        // ---------- messages ----------
        public bool TrySay(string[] list, double prob, bool ignoreGap = false)
        {
            if (!cfg.MessagesEnabled) return false;
            if (rnd.NextDouble() > prob) return false;
            if (!ignoreGap && (bubble != null || sinceSay < 6)) return false;
            string t = Msg.Pick(list);
            bubble = t; bubbleLeft = Math.Max(3.0, 1.8 + t.Length * 0.08); sinceSay = 0;
            return true;
        }

        // ---------- state machine ----------
        void SetAnim(string n) { if (animName != n) { animName = n; frameT = 0; } }
        void Dur(double a, double b) { stateDur = (a + (b - a) * rnd.NextDouble()) * (1.2 - 0.4 * cfg.Randomness / 100.0); }

        int ChooseDir()
        {
            double l = X - area.Left, r = area.Right - X;
            if (l < P(30)) return 1;
            if (r < P(30)) return -1;
            return rnd.Next(2) == 0 ? -1 : 1;
        }

        void Enter(S s)
        {
            state = s; stateT = 0; frameT = 0; forceFrame = -1; stateDur = 0;
            switch (s)
            {
                case S.Idle: animName = "idle"; Dur(1.5, 5); break;
                case S.Look: animName = "look"; Dur(1.5, 2.8); break;
                case S.Walk: animName = "walk"; Dur(2, 6); facing = ChooseDir(); break;
                case S.Run: animName = "run"; Dur(1.5, 3.5); facing = ChooseDir(); break;
                case S.Jump: animName = "jump"; launched = false; break;
                case S.Sit: animName = "sit"; Dur(3, 8); break;
                case S.Bored: animName = "bored"; Dur(3, 6); TrySay(Msg.Bored, 0.4); break;
                case S.Nap: animName = "nap"; Dur(7, 16); TrySay(Msg.Sleep, 0.85); break;
                case S.Wake: animName = "wake"; stateDur = 1.1; TrySay(Msg.Wake, 0.4); break;
                case S.Study: animName = "study"; Dur(5, 10); TrySay(Msg.Study, 0.6); break;
                case S.Flip: animName = "flip"; stateDur = 0.9; break;
                case S.Upside: animName = "upside"; Dur(3, 5); TrySay(Msg.Upside, 0.5); break;
                case S.DeskBored: animName = "deskbored"; Dur(3, 5); TrySay(Msg.Bored, 0.4); break;
                case S.Throw: animName = "throw"; stateDur = 1.4; TrySay(Msg.Throw, 0.9, true); break;
                case S.Watch: animName = "watch"; Dur(6, 15); TrySay(Msg.Watch, 0.5); break;
                case S.Cheer: animName = "cheer"; stateDur = 1.6; TrySay(Msg.Cheer, 0.85, true); break;
                case S.Chase: animName = "run"; stateDur = 14; break;
                case S.Kick: animName = "kick"; stateDur = 0.5; kicked = false; break;
                case S.WatchBall: animName = "idle"; stateDur = 14; break;
                case S.SitBall: animName = "sit"; break;
                case S.Fall: animName = "fall"; stateDur = 2.4; TrySay(Msg.Fall, 0.6, true); break;
                case S.Held: animName = "held"; break;
                case S.Air: animName = "jump"; forceFrame = 2; break;
                case S.Angry: animName = "angry"; stateDur = 2.5; break;
            }
        }

        S Weighted(params (S s, double w)[] o)
        {
            double r = cfg.Randomness / 100.0; int cnt = 0; double tot = 0;
            foreach (var x in o) if (x.w > 0) { cnt++; tot += x.w; }
            if (cnt == 0) return S.Idle;
            bool uniform = rnd.NextDouble() < r * 0.35;
            double pick = uniform ? rnd.NextDouble() * cnt : rnd.NextDouble() * tot;
            foreach (var x in o)
            {
                if (x.w <= 0) continue;
                double w = uniform ? 1 : x.w;
                if (pick < w) return x.s;
                pick -= w;
            }
            return o[o.Length - 1].s;
        }

        void Finish()
        {
            bool mv = CanMove; bool lonely = sinceInteract > 90; S n;
            switch (state)
            {
                case S.Idle:
                    n = Weighted((S.Look, 2), (S.Walk, mv ? (lonely ? 7 : 5) : 0), (S.Run, mv ? (lonely ? 3 : 1) : 0),
                                 (S.Jump, lonely ? 3 : 1.5), (S.Sit, lonely ? 3 : 5), (S.Idle, sinceSay > 20 ? 2.5 : 0.5));
                    if (n == S.Idle) { TrySay(Msg.General, 1.0); Enter(S.Idle); }
                    else { Enter(n); if (n == S.Look) facing = rnd.Next(2) == 0 ? 1 : -1; }
                    break;
                case S.Look: Enter(Weighted((S.Idle, 3), (S.Walk, mv ? 3 : 0), (S.Sit, 1))); break;
                case S.Walk: Enter(Weighted((S.Idle, 4), (S.Walk, mv ? 2 : 0), (S.Run, mv ? 1 : 0), (S.Sit, 1), (S.Look, 1))); break;
                case S.Run: Enter(Weighted((S.Idle, 3), (S.Jump, 1.5), (S.Walk, mv ? 2 : 0))); break;
                case S.Jump: Enter(S.Idle); break;
                case S.Sit: Enter(Weighted((S.Idle, 2), (S.Bored, 3), (S.Nap, 2), (S.Study, 3), (S.Watch, 3))); break;
                case S.Bored: Enter(Weighted((S.Sit, 2), (S.Nap, 2), (S.Idle, 1.5), (S.Study, 1))); break;
                case S.Nap: Enter(S.Wake); break;
                case S.Wake: Enter(S.Sit); break;
                case S.Study:
                    n = Weighted((S.Flip, 3), (S.Upside, 1.5), (S.DeskBored, 3), (S.Jump, 0.8));
                    if (n == S.Jump) TrySay(Msg.Quit, 0.8, true);
                    Enter(n); break;
                case S.Flip: Enter(Weighted((S.Study, 3), (S.DeskBored, 2))); break;
                case S.Upside:
                    n = Weighted((S.Study, 2), (S.DeskBored, 2), (S.Jump, 1));
                    if (n == S.Jump) TrySay(Msg.Quit, 0.8, true);
                    Enter(n); break;
                case S.DeskBored:
                    n = Weighted((S.Throw, 3), (S.Jump, 1.5), (S.Study, 1.5), (S.Sit, 1.5));
                    if (n == S.Jump) TrySay(Msg.Quit, 0.8, true);
                    Enter(n); break;
                case S.Throw: Enter(S.Nap); break;
                case S.Watch: Enter(Weighted((S.Watch, 3), (S.Cheer, 3), (S.Sit, 1), (S.Idle, 1))); break;
                case S.Cheer:
                    if (mv) { SpawnBall(); kicksLeft = 2 + rnd.Next(3); Enter(S.Chase); TrySay(Msg.Run, 0.8, true); }
                    else Enter(S.Watch);
                    break;
                case S.Kick:
                    kicksLeft--;
                    if (kicksLeft > 0 && ballActive) Enter(S.Chase); else Enter(S.WatchBall);
                    break;
                case S.Chase: Enter(S.WatchBall); break;
                case S.WatchBall: Enter(ballActive ? S.SitBall : S.Watch); break;
                case S.Fall: Enter(S.Wake); break;
                default: Enter(S.Idle); break;
            }
        }

        void MoveX(double d)
        {
            X += facing * d; double m = P(16);
            if (X < area.Left + m) { X = area.Left + m; facing = 1; }
            else if (X > area.Right - m) { X = area.Right - m; facing = -1; }
        }

        void UpdateState(double dt)
        {
            if (!CanMove && (state == S.Walk || state == S.Run || state == S.Chase || state == S.Kick || state == S.WatchBall))
            { KillBall(); Enter(S.Idle); return; }
            switch (state)
            {
                case S.Walk:
                    MoveX(P(22) * cfg.Speed * dt);
                    if (rnd.NextDouble() < 0.012 * Rf * dt) Enter(S.Fall);
                    break;
                case S.Run:
                    MoveX(P(60) * cfg.Speed * dt);
                    if (rnd.NextDouble() < 0.02 * Rf * dt) Enter(S.Fall);
                    break;
                case S.Jump:
                    if (stateT < 0.12) { forceFrame = 0; break; }
                    if (!launched) { launched = true; vy = -P(115); }
                    Y += vy * dt; vy += P(300) * dt;
                    forceFrame = vy < 0 ? 1 : 2;
                    if (Y >= area.Bottom) { Y = area.Bottom; Finish(); }
                    break;
                case S.Air:
                    Y += vy * dt; vy += P(300) * dt;
                    if (Y >= area.Bottom)
                    {
                        Y = area.Bottom;
                        if (Y - airStartY > P(70)) Enter(S.Fall);
                        else { Enter(S.Idle); TrySay(Msg.Land, 0.4); }
                        Persist();
                    }
                    break;
                case S.Chase:
                    if (!ballActive) { Enter(S.Watch); break; }
                    {
                        double dx = bX - X;
                        if (Math.Abs(dx) > P(6)) facing = dx > 0 ? 1 : -1;
                        if (Math.Abs(dx) > P(14)) { SetAnim("run"); X += Math.Sign(dx) * P(55) * cfg.Speed * dt; ClampX(); }
                        else
                        {
                            bool low = bY > area.Bottom - P(16);
                            if (low || stateT > 10) Enter(S.Kick); else SetAnim("idle");
                        }
                    }
                    break;
                case S.Kick:
                    if (!kicked && stateT > 0.15)
                    {
                        kicked = true;
                        if (ballActive && Math.Abs(bX - X) < P(34)) { KickBall(facing, 110 + rnd.NextDouble() * 230); TrySay(Msg.Kick, 0.4, true); }
                    }
                    break;
                case S.WatchBall:
                    if (!ballActive) { Enter(S.Watch); break; }
                    facing = bX >= X ? 1 : -1;
                    if (ballSpinning) Enter(S.SitBall);
                    break;
                case S.SitBall:
                    if (!ballActive) { Enter(S.Watch); break; }
                    facing = bX >= X ? 1 : -1;
                    break;
            }
        }

        // ---------- ball ----------
        void SpawnBall()
        {
            bX = area.Left + P(40) + rnd.NextDouble() * Math.Max(1, area.Width - P(80));
            bY = area.Top; bVX = (rnd.NextDouble() - 0.5) * P(120); bVY = 0; bAngle = 0; bRest = 0; bSpin = 0; bLife = 0;
            ballActive = true; ballSpinning = false;
            if (!ballView.Visible) ballView.Show();
            ballView.Reassert();
        }

        void KillBall() { ballActive = false; ballSpinning = false; if (ballView.Visible) ballView.Hide(); }

        void KickBall(double dir, double powerSpx)
        {
            bVX = dir * P(powerSpx); bVY = -P(40 + rnd.NextDouble() * 80);
            ballSpinning = false; bSpin = 0; bRest = 0;
        }

        void OnBallClicked()
        {
            if (!ballActive) return;
            sinceInteract = 0;
            KickBall(Cursor.Position.X < bX ? 1 : -1, 150 + rnd.NextDouble() * 200);
        }

        void UpdateBall(double dt)
        {
            if (!ballActive) return;
            bLife += dt;
            if (bLife > 40) { KillBall(); return; }
            double r = P(7);
            if (!ballSpinning)
            {
                bVY += P(300) * dt; bY += bVY * dt; bX += bVX * dt;
                if (bY >= area.Bottom) { bY = area.Bottom; if (Math.Abs(bVY) > P(30)) bVY = -bVY * 0.55; else bVY = 0; }
                bool onGround = bY >= area.Bottom - 0.5;
                if (onGround) bVX *= Math.Exp(-0.55 * dt);
                if (bX < area.Left + r) { bX = area.Left + r; bVX = Math.Abs(bVX) * 0.85; }
                if (bX > area.Right - r) { bX = area.Right - r; bVX = -Math.Abs(bVX) * 0.85; }
                bAngle += bVX * dt / r * 57.3;
                if (onGround && Math.Abs(bVX) < P(5) && Math.Abs(bVY) < P(5))
                { bRest += dt; bVX = 0; if (bRest > 0.5) { ballSpinning = true; bSpin = 0; } }
                else bRest = 0;
            }
            else
            {
                bSpin += dt; bAngle += dt * 400;
                if (bSpin > 3.5) { KillBall(); return; }
            }
            int f = ((int)Math.Floor(bAngle / 30.0) % 4 + 4) % 4;
            ballView.Render(f, bX, bY);
        }

        // ---------- per-tick ----------
        public void Update(double dt)
        {
            if (Paused && state != S.Held && state != S.Air) return;
            if (dt > 0.1) dt = 0.1;
            sinceSay += dt; sinceInteract += dt; sinceProx += dt; areaT += dt; topT += dt; stateT += dt;
            frameT += dt * ((state == S.Walk || state == S.Run || state == S.Chase) ? cfg.Speed : 1.0);
            if (!cfg.MessagesEnabled) bubble = null;
            if (bubble != null) { bubbleLeft -= dt; if (bubbleLeft <= 0) bubble = null; }
            if (areaT > 2 && state != S.Held) { areaT = 0; RefreshArea(); }
            if (topT > 5) { topT = 0; view.Reassert(); if (ballActive) ballView.Reassert(); }
            UpdateState(dt);
            UpdateBall(dt);
            Proximity();
            if (stateDur > 0 && stateT >= stateDur) Finish();
            if (state != S.Held && state != S.Air && state != S.Jump) { Y = area.Bottom; ClampX(); }
            Render();
        }

        void Proximity()
        {
            if (sinceProx < 20) return;
            if (!(state == S.Idle || state == S.Walk || state == S.Look || state == S.Sit)) return;
            var c = Cursor.Position; double dx = c.X - X, dy = c.Y - (Y - P(22)); double lim = P(50);
            if (dx * dx + dy * dy < lim * lim)
            {
                sinceProx = 0;
                if (state != S.Sit) Enter(S.Look);
                facing = dx >= 0 ? 1 : -1;
                TrySay(Msg.Hover, 0.35);
            }
        }

        void Render()
        {
            var a = Sprites.Get(animName); int n = a.Frames; int f;
            if (forceFrame >= 0) f = Math.Min(forceFrame, n - 1);
            else if (a.Loop) f = (int)(frameT * a.Fps) % n;
            else f = Math.Min(n - 1, (int)(frameT * a.Fps));
            int key = HashCode.Combine(animName, f, (int)Math.Round(X), (int)Math.Round(Y), facing, bubble);
            if (key == lastKey) return;
            lastKey = key;
            view.Render(a, f, facing < 0, X, Y, bubble, area);
        }

        // ---------- user interaction ----------
        public void OnClick()
        {
            sinceInteract = 0;
            var now = DateTime.Now; clicks.Add(now);
            clicks.RemoveAll(t => (now - t).TotalSeconds > 5);
            if (clicks.Count >= 5)
            {
                clicks.Clear(); Enter(S.Angry); TrySay(Msg.Angry, 1.0, true); return;
            }
            if (state == S.Nap || state == S.Fall) { Enter(S.Wake); }
            else if (state == S.Idle || state == S.Walk || state == S.Run || state == S.Look)
            { double dx = Cursor.Position.X - X; Enter(S.Look); facing = dx >= 0 ? 1 : -1; }
            TrySay(Msg.Click, 1.0, true);
        }

        public void OnDragStart()
        {
            sinceInteract = 0;
            if (cfg.Pinned) { dragIgnored = true; TrySay(Msg.Pinned, 0.7, true); return; }
            dragIgnored = false;
            Enter(S.Held);
            TrySay(Msg.Lift, 0.85, true);
        }

        public void OnDrag(Point p)
        {
            if (dragIgnored || state != S.Held) return;
            try { area = Screen.FromPoint(p).WorkingArea; } catch { }
            X = p.X; Y = p.Y + P(30);
        }

        public void OnDragEnd()
        {
            if (dragIgnored) { dragIgnored = false; return; }
            if (state != S.Held) return;
            var p = Cursor.Position;
            try { area = Screen.FromPoint(p).WorkingArea; } catch { }
            if (Y > area.Bottom) Y = area.Bottom;
            ClampX();
            if (Y < area.Bottom - 2) { airStartY = Y; vy = 0; Enter(S.Air); }
            else { Y = area.Bottom; Enter(S.Idle); Persist(); }
        }
    }
}
