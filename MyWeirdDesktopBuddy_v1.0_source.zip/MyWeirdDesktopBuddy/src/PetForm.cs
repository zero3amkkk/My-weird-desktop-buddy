using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;

namespace WeirdBuddy
{
    internal sealed class PetForm : LayeredForm
    {
        Surface surf; int W, H, scale, dpi;
        Font font; StringFormat sf; Rectangle spriteRect;
        string cacheText; SizeF cacheSize;
        bool pressed, dragging; Point pressPos;

        public event Action Clicked;
        public event Action DragStarted;
        public event Action<Point> Dragging;
        public event Action DragEnded;
        public event Action RightClicked;

        public void Setup(int sc)
        {
            scale = sc; dpi = Dpi.Factor;
            W = Math.Max(Sprites.Cell * sc + 24, 280 * dpi);
            H = Sprites.Cell * sc + 140 * dpi;
            if (surf != null) surf.Dispose();
            surf = new Surface(W, H);
            if (font != null) font.Dispose();
            font = new Font("Segoe UI", 14f * dpi, FontStyle.Bold, GraphicsUnit.Pixel);
            if (sf != null) sf.Dispose();
            sf = new StringFormat(StringFormatFlags.DirectionRightToLeft) { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
            cacheText = null;
        }

        public void Render(Anim a, int frame, bool flip, double feetX, double feetY, string bubble, Rectangle bounds)
        {
            if (surf == null || !Visible) return;
            int winX = (int)Math.Round(feetX) - W / 2;
            int winY = (int)Math.Round(feetY) - (H - scale);
            var g = surf.G;
            g.CompositingMode = CompositingMode.SourceCopy;
            g.Clear(Color.Transparent);
            g.CompositingMode = CompositingMode.SourceOver;
            int sx = (W - Sprites.Cell * scale) / 2, sy = H - Sprites.Cell * scale;
            spriteRect = new Rectangle(sx, sy, Sprites.Cell * scale, Sprites.Cell * scale);
            g.SmoothingMode = SmoothingMode.None;
            g.InterpolationMode = InterpolationMode.NearestNeighbor;
            g.PixelOffsetMode = PixelOffsetMode.Half;
            Sprites.Draw(g, a.Sheet, Sprites.Cell, frame, sx, sy, scale, flip);
            if (!string.IsNullOrEmpty(bubble)) DrawBubble(g, bubble, winX, sy, bounds);
            surf.Push(Handle, winX, winY);
        }

        static GraphicsPath Round(Rectangle r, int rad)
        {
            var p = new GraphicsPath(); int d = rad * 2;
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        void DrawBubble(Graphics g, string text, int winX, int spriteTop, Rectangle bounds)
        {
            g.TextRenderingHint = TextRenderingHint.AntiAlias;
            if (text != cacheText) { cacheSize = g.MeasureString(text, font, 230 * dpi, sf); cacheText = text; }
            int pad = 10 * dpi, tail = 10 * dpi;
            int bw = Math.Max((int)Math.Ceiling(cacheSize.Width) + pad * 2, 60 * dpi);
            int bh = (int)Math.Ceiling(cacheSize.Height) + pad * 2;
            int by = Math.Max(2, spriteTop + 12 * scale - tail - bh);
            int bx = W / 2 - bw / 2;
            int minX = Math.Max(4, bounds.Left - winX + 4), maxX = Math.Min(W - 4 - bw, bounds.Right - winX - 4 - bw);
            if (maxX >= minX) bx = Math.Min(Math.Max(bx, minX), maxX);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (var path = Round(new Rectangle(bx, by, bw, bh), 8 * dpi))
            using (var fill = new SolidBrush(Color.FromArgb(255, 255, 252, 240)))
            using (var pen = new Pen(Color.FromArgb(255, 40, 30, 40), 2f * dpi))
            using (var fillPen = new Pen(Color.FromArgb(255, 255, 252, 240), 2f * dpi + 1))
            using (var tb = new SolidBrush(Color.FromArgb(255, 30, 24, 36)))
            {
                int tx = Math.Min(Math.Max(W / 2, bx + 16 * dpi), bx + bw - 16 * dpi);
                var tri = new Point[] { new Point(tx - 7 * dpi, by + bh - 1), new Point(tx + 7 * dpi, by + bh - 1), new Point(tx, by + bh + tail) };
                g.FillPath(fill, path); g.FillPolygon(fill, tri);
                g.DrawPath(pen, path);
                g.DrawLine(pen, tri[0], tri[2]); g.DrawLine(pen, tri[1], tri[2]);
                g.DrawLine(fillPen, tri[0].X + 1, by + bh, tri[1].X - 1, by + bh);
                g.DrawString(text, font, tb, new RectangleF(bx + pad, by + pad, bw - 2 * pad, bh - 2 * pad), sf);
            }
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (!spriteRect.Contains(e.Location)) return;
            if (e.Button == MouseButtons.Left) { pressed = true; dragging = false; pressPos = Cursor.Position; Capture = true; }
            else if (e.Button == MouseButtons.Right) { var h = RightClicked; if (h != null) h(); }
        }
        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (!pressed) return;
            var p = Cursor.Position;
            if (!dragging && Math.Abs(p.X - pressPos.X) + Math.Abs(p.Y - pressPos.Y) > 6)
            { dragging = true; var h = DragStarted; if (h != null) h(); }
            if (dragging) { var h2 = Dragging; if (h2 != null) h2(p); }
        }
        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            if (e.Button != MouseButtons.Left || !pressed) return;
            pressed = false; Capture = false;
            if (dragging) { dragging = false; var h = DragEnded; if (h != null) h(); }
            else { var c = Clicked; if (c != null) c(); }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) { if (surf != null) surf.Dispose(); if (font != null) font.Dispose(); if (sf != null) sf.Dispose(); }
            base.Dispose(disposing);
        }
    }

    internal sealed class BallForm : LayeredForm
    {
        Surface surf; int scale, size;
        public event Action Clicked;

        public void Setup(int sc)
        {
            scale = sc; size = Sprites.BallCell * sc;
            if (surf != null) surf.Dispose();
            surf = new Surface(size, size);
        }

        /// <summary>(bx,by) = bottom-centre of the ball.</summary>
        public void Render(int frame, double bx, double by)
        {
            if (surf == null || !Visible) return;
            var g = surf.G;
            g.CompositingMode = CompositingMode.SourceCopy; g.Clear(Color.Transparent); g.CompositingMode = CompositingMode.SourceOver;
            g.SmoothingMode = SmoothingMode.None; g.InterpolationMode = InterpolationMode.NearestNeighbor; g.PixelOffsetMode = PixelOffsetMode.Half;
            Sprites.Draw(g, Sprites.Ball, Sprites.BallCell, frame, 0, 0, scale, false);
            surf.Push(Handle, (int)Math.Round(bx) - size / 2, (int)Math.Round(by) - 14 * scale);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Button == MouseButtons.Left) { var c = Clicked; if (c != null) c(); }
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing && surf != null) surf.Dispose();
            base.Dispose(disposing);
        }
    }
}
