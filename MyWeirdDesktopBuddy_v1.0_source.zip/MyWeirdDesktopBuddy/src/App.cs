using System;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

namespace WeirdBuddy
{
    internal static class Program
    {
        [STAThread]
        static int Main(string[] args)
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (args.Length > 0 && args[0] == "--selftest") return SelfTest.Run();

            bool created;
            using (var mutex = new Mutex(true, @"Local\MyWeirdDesktopBuddy.SingleInstance", out created))
            {
                if (!created)
                {
                    // Second instance: silently ask the running one to show itself, then exit with code 2.
                    try { using (var ev = EventWaitHandle.OpenExisting(BuddyApp.ShowEventName)) ev.Set(); } catch { }
                    return 2;
                }
                Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
                Application.ThreadException += (s, e) => Log.Error("ThreadException", e.Exception);
                AppDomain.CurrentDomain.UnhandledException += (s, e) => Log.Write("UnhandledException: " + e.ExceptionObject);
                try
                {
                    Log.Write("Starting v" + Application.ProductVersion);
                    Sprites.Load();
                    Application.Run(new BuddyApp());
                    return 0;
                }
                catch (Exception ex)
                {
                    Log.Error("fatal", ex);
                    MessageBox.Show("حصلت مشكلة وقت التشغيل. تفاصيل المشكلة محفوظة في:\n" + Paths.LogFile, "My Weird Desktop Buddy",
                        MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading | MessageBoxOptions.RightAlign);
                    return 1;
                }
            }
        }
    }

    /// <summary>Hidden message-only window that owns the global hotkey (Ctrl+Alt+B).</summary>
    internal sealed class HotkeyWindow : NativeWindow, IDisposable
    {
        const int Id = 0xB0DD;
        readonly Action callback;
        public readonly bool Registered;
        public HotkeyWindow(Action cb)
        {
            callback = cb;
            CreateHandle(new CreateParams { Parent = new IntPtr(-3) }); // HWND_MESSAGE
            Registered = Native.RegisterHotKey(Handle, Id, 0x1 | 0x2 | 0x4000, 0x42); // ALT|CTRL|NOREPEAT + 'B'
            if (!Registered) Log.Write("RegisterHotKey(Ctrl+Alt+B) failed - probably used by another app");
        }
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == Native.WM_HOTKEY && m.WParam.ToInt32() == Id) { callback(); return; }
            base.WndProc(ref m);
        }
        public void Dispose()
        {
            if (Handle != IntPtr.Zero) { Native.UnregisterHotKey(Handle, Id); DestroyHandle(); }
        }
    }

    internal sealed class BuddyApp : ApplicationContext
    {
        readonly AppSettings cfg; readonly PetForm pet; readonly BallForm ball; readonly PetBrain brain;
        NotifyIcon tray; System.Windows.Forms.Timer timer; readonly Stopwatch sw = new Stopwatch();
        public const string ShowEventName = @"Local\MyWeirdDesktopBuddy.Show";
        HotkeyWindow hotkey; SettingsForm settingsForm;
        EventWaitHandle showEvent; RegisteredWaitHandle showWait;
        ToolStripMenuItem miMsg, miPin, miAuto, miPause, miResume;
        bool visible = true; int errors; int curScale;

        int EffScale() { return cfg.Scale * Dpi.Factor; }

        public BuddyApp()
        {
            cfg = AppSettings.Load();
            pet = new PetForm(); ball = new BallForm();
            curScale = EffScale();
            pet.Setup(curScale); ball.Setup(curScale);
            brain = new PetBrain(cfg, pet, ball);
            pet.Clicked += () => brain.OnClick();
            pet.DragStarted += () => brain.OnDragStart();
            pet.Dragging += p => brain.OnDrag(p);
            pet.DragEnded += () => brain.OnDragEnd();
            pet.RightClicked += ShowMenuAtCursor;
            pet.Show();
            BuildTray();
            brain.Start(curScale);
            hotkey = new HotkeyWindow(ToggleVisible);
            SystemEvents.DisplaySettingsChanged += OnDisplayChanged;
            showEvent = new EventWaitHandle(false, EventResetMode.AutoReset, ShowEventName);
            showWait = ThreadPool.RegisterWaitForSingleObject(showEvent, (st, timedOut) =>
            {
                try
                {
                    if (!pet.IsDisposed && pet.IsHandleCreated)
                        pet.BeginInvoke(new Action(() => { bool was = visible; ShowPet(); if (was) brain.Greet(); }));
                }
                catch { }
            }, null, -1, false);
            if (cfg.RunAtStartup) Startup.Set(true); // keeps the registry path correct if the EXE was moved
            timer = new System.Windows.Forms.Timer { Interval = 33 };
            timer.Tick += OnTick;
            sw.Start(); timer.Start();
            if (!cfg.FirstRunDone)
            {
                cfg.FirstRunDone = true; cfg.Save();
                tray.ShowBalloonTip(6000, "My Weird Desktop Buddy",
                    "أنا شغال! كليك يمين على أيقونتي جنب الساعة للتحكم. اختصار الإخفاء/الإظهار: Ctrl+Alt+B", ToolTipIcon.Info);
            }
        }

        void OnTick(object sender, EventArgs e)
        {
            double dt = sw.Elapsed.TotalSeconds; sw.Restart();
            if (!visible) return;
            try { brain.Update(dt); errors = 0; }
            catch (Exception ex)
            {
                Log.Error("tick", ex);
                if (++errors > 20) { errors = 0; try { brain.Reset(); } catch (Exception e2) { Log.Error("reset", e2); } }
            }
        }

        void ShowPet()
        {
            if (visible) return;
            visible = true; pet.Show(); brain.SetHidden(false); sw.Restart(); timer.Start(); brain.ForceRedraw();
        }
        void HidePet()
        {
            if (!visible) return;
            visible = false; timer.Stop(); brain.SetHidden(true); pet.Hide(); ball.Hide();
        }
        void ToggleVisible() { if (visible) HidePet(); else ShowPet(); }

        void OnDisplayChanged(object s, EventArgs e)
        {
            try
            {
                if (pet.IsHandleCreated && !pet.IsDisposed)
                    pet.BeginInvoke(new Action(() => { try { brain.HandleDisplayChange(); } catch (Exception ex) { Log.Error("display change", ex); } }));
            }
            catch (Exception ex) { Log.Error("display change dispatch", ex); }
        }

        void ApplySettings()
        {
            cfg.Clamp();
            int sc = EffScale();
            if (sc != curScale) { curScale = sc; pet.Setup(sc); ball.Setup(sc); brain.SetScale(sc); }
            Startup.Set(cfg.RunAtStartup);
            cfg.Save();
            if (visible) brain.ForceRedraw();
        }

        void OpenSettings()
        {
            if (settingsForm != null && !settingsForm.IsDisposed) { settingsForm.Activate(); return; }
            settingsForm = new SettingsForm(cfg, ApplySettings);
            settingsForm.Show();
        }

        void ShowMenuAtCursor()
        {
            try { Native.SetForegroundWindow(pet.Handle); tray.ContextMenuStrip.Show(Cursor.Position); }
            catch (Exception e) { Log.Error("pet menu", e); }
        }

        void BuildTray()
        {
            var menu = new ContextMenuStrip { RightToLeft = RightToLeft.Yes };
            var hint = new ToolStripMenuItem("اختصار الإظهار/الإخفاء: Ctrl+Alt+B") { Enabled = false };
            menu.Items.Add(hint);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("إظهار الشخصية", null, (s, e) => ShowPet());
            menu.Items.Add("إخفاء الشخصية", null, (s, e) => HidePet());
            menu.Items.Add(new ToolStripSeparator());
            miPause = (ToolStripMenuItem)menu.Items.Add("إيقاف الأنيميشنات مؤقتًا", null, (s, e) => { brain.Paused = true; });
            miResume = (ToolStripMenuItem)menu.Items.Add("استئناف الأنيميشنات", null, (s, e) => { brain.Paused = false; });
            menu.Items.Add(new ToolStripSeparator());
            miMsg = (ToolStripMenuItem)menu.Items.Add("تشغيل/إيقاف الرسائل العشوائية", null, (s, e) => { cfg.MessagesEnabled = !cfg.MessagesEnabled; cfg.Save(); });
            miPin = (ToolStripMenuItem)menu.Items.Add("تثبيت الشخصية في مكانها", null, (s, e) => { cfg.Pinned = !cfg.Pinned; cfg.Save(); });
            miAuto = (ToolStripMenuItem)menu.Items.Add("السماح بالحركة التلقائية", null, (s, e) => { cfg.AutoMove = !cfg.AutoMove; cfg.Save(); });
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("فتح الإعدادات...", null, (s, e) => OpenSettings());
            menu.Items.Add("الخروج من البرنامج نهائيًا", null, (s, e) => ExitApp());
            menu.Opening += (s, e) =>
            {
                miMsg.Checked = cfg.MessagesEnabled; miPin.Checked = cfg.Pinned; miAuto.Checked = cfg.AutoMove;
                miPause.Enabled = !brain.Paused; miResume.Enabled = brain.Paused;
            };
            tray = new NotifyIcon { Icon = Sprites.AppIcon, Text = "My Weird Desktop Buddy", ContextMenuStrip = menu, Visible = true };
            tray.DoubleClick += (s, e) => ToggleVisible();
        }

        void ExitApp()
        {
            try { timer.Stop(); brain.Persist(); cfg.Save(); } catch (Exception e) { Log.Error("exit save", e); }
            try { SystemEvents.DisplaySettingsChanged -= OnDisplayChanged; } catch { }
            try { hotkey.Dispose(); } catch { }
            try { if (showWait != null) showWait.Unregister(null); if (showEvent != null) showEvent.Dispose(); } catch { }
            try { if (settingsForm != null && !settingsForm.IsDisposed) settingsForm.Close(); } catch { }
            tray.Visible = false; tray.Dispose();
            ball.Dispose(); pet.Dispose();
            Log.Write("Exit");
            ExitThread();
        }
    }
}
