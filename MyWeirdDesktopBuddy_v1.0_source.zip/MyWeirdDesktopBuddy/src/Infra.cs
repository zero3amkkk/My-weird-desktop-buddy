using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Win32;

namespace WeirdBuddy
{
    internal static class Paths
    {
        public static readonly string Dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "MyWeirdDesktopBuddy");
        public static string SettingsFile { get { return Path.Combine(Dir, "settings.json"); } }
        public static string LogFile { get { return Path.Combine(Dir, "log.txt"); } }
    }

    internal static class Log
    {
        static readonly object L = new object();
        public static void Write(string msg)
        {
            try
            {
                lock (L)
                {
                    Directory.CreateDirectory(Paths.Dir);
                    var fi = new FileInfo(Paths.LogFile);
                    if (fi.Exists && fi.Length > 512 * 1024)
                    {
                        string old = Paths.LogFile + ".old";
                        if (File.Exists(old)) File.Delete(old);
                        File.Move(Paths.LogFile, old);
                    }
                    File.AppendAllText(Paths.LogFile, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + msg + Environment.NewLine);
                }
            }
            catch { }
        }
        public static void Error(string where, Exception e) { Write("ERROR in " + where + ": " + e); }
    }

    internal sealed class AppSettings
    {
        public double Speed { get; set; } = 1.0;        // 0.5 .. 2.0
        public int Scale { get; set; } = 3;             // 2 .. 6
        public int Randomness { get; set; } = 50;       // 0 .. 100
        public bool MessagesEnabled { get; set; } = true;
        public bool AutoMove { get; set; } = true;
        public bool Pinned { get; set; } = false;
        public bool RunAtStartup { get; set; } = false;
        public bool FirstRunDone { get; set; } = false;
        public bool HasPos { get; set; } = false;
        public int PosX { get; set; }
        public int PosY { get; set; }
        [JsonIgnore] public bool NoSave { get; set; }

        public static AppSettings Load()
        {
            try
            {
                if (File.Exists(Paths.SettingsFile))
                {
                    var s = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(Paths.SettingsFile));
                    if (s != null) { s.Clamp(); return s; }
                }
            }
            catch (Exception e) { Log.Error("load settings", e); }
            return new AppSettings();
        }

        public void Save()
        {
            if (NoSave) return;
            try
            {
                Directory.CreateDirectory(Paths.Dir);
                string tmp = Paths.SettingsFile + ".tmp";
                File.WriteAllText(tmp, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
                File.Move(tmp, Paths.SettingsFile, true);
            }
            catch (Exception e) { Log.Error("save settings", e); }
        }

        public void Clamp()
        {
            Speed = Math.Min(2.0, Math.Max(0.5, Speed));
            Scale = Math.Min(6, Math.Max(2, Scale));
            Randomness = Math.Min(100, Math.Max(0, Randomness));
        }

        public void ResetDefaults()
        {
            var d = new AppSettings();
            Speed = d.Speed; Scale = d.Scale; Randomness = d.Randomness;
            MessagesEnabled = d.MessagesEnabled; AutoMove = d.AutoMove; Pinned = d.Pinned; RunAtStartup = d.RunAtStartup;
        }
    }

    internal static class Startup
    {
        const string KeyPath = @"Software\Microsoft\Windows\CurrentVersion\Run";
        const string ValueName = "MyWeirdDesktopBuddy";
        public static void Set(bool on)
        {
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(KeyPath, true))
                {
                    if (k == null) return;
                    if (on) k.SetValue(ValueName, "\"" + Environment.ProcessPath + "\"");
                    else k.DeleteValue(ValueName, false);
                }
            }
            catch (Exception e) { Log.Error("startup registry", e); }
        }
    }
}
