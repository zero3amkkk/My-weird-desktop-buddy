using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Windows.Forms;

namespace WeirdBuddy
{
    /// <summary>Run with: MyWeirdDesktopBuddy.exe --selftest. Exercises sprites, windows, state machine, drag/drop, hide/show. Result: %TEMP%\buddy_selftest.txt, exit code 0 = all passed.</summary>
    internal static class SelfTest
    {
        public static int Run()
        {
            var sb = new StringBuilder(); bool ok = true;
            Action<string, bool> chk = (n, r) => { sb.AppendLine((r ? "PASS  " : "FAIL  ") + n); if (!r) ok = false; };
            try
            {
                Sprites.Load();
                string[] need = { "idle", "look", "walk", "run", "jump", "sit", "bored", "nap", "wake", "study", "flip", "upside",
                                  "deskbored", "throw", "watch", "cheer", "kick", "fall", "held", "angry" };
                foreach (var n in need)
                {
                    bool has; try { has = Sprites.Get(n).Frames > 0; } catch { has = false; }
                    chk("animation loaded: " + n, has);
                }
                chk("ball sheet loaded", Sprites.Ball != null && Sprites.Ball.Width == 64);
                chk("app icon loaded", Sprites.AppIcon != null);

                var cfg = new AppSettings { NoSave = true, Randomness = 100 };
                var back = JsonSerializer.Deserialize<AppSettings>(JsonSerializer.Serialize(cfg));
                chk("settings JSON round-trip", back != null && back.Randomness == 100);

                var pet = new PetForm(); var ball = new BallForm();
                pet.Setup(3); ball.Setup(3);
                var brain = new PetBrain(cfg, pet, ball);
                pet.Show(); brain.Start(3);
                chk("pet window visible", pet.Visible);

                int errs = 0;
                foreach (S s in Enum.GetValues(typeof(S)))
                {
                    if (s == S.Held) continue;
                    brain.DebugForce(s);
                    for (int i = 0; i < 90; i++)
                    {
                        try { brain.Update(0.033); } catch (Exception e) { errs++; sb.AppendLine("   exception in state " + s + ": " + e); }
                        if (i % 10 == 0) Application.DoEvents();
                    }
                }
                chk("every state runs for 3s without exceptions", errs == 0);

                errs = 0; brain.DebugForce(S.Idle);
                for (int i = 0; i < 6000; i++)
                {
                    try { brain.Update(0.033); } catch (Exception e) { errs++; sb.AppendLine("   exception: " + e); }
                    if (i % 20 == 0) Application.DoEvents();
                }
                chk("200s of random behaviour without exceptions", errs == 0);

                errs = 0;
                try
                {
                    brain.OnClick();
                    for (int i = 0; i < 6; i++) brain.OnClick();   // spam clicks -> angry
                    brain.OnDragStart(); brain.OnDrag(new Point(400, 200)); brain.Update(0.033); brain.OnDragEnd();
                    for (int i = 0; i < 200; i++) brain.Update(0.033);
                }
                catch (Exception e) { errs++; sb.AppendLine("   exception: " + e); }
                chk("click / drag / drop / fall", errs == 0);

                pet.Hide(); chk("hide", !pet.Visible);
                pet.Show(); brain.SetHidden(false); brain.ForceRedraw(); chk("show again", pet.Visible);

                chk("messages: all lists non-empty", Msg.General.Length > 20 && Msg.Study.Length > 0 && Msg.Click.Length > 0 && Msg.Angry.Length > 0);
                chk("key phrase present", Array.IndexOf(Msg.Study, Msg.Key) >= 0);
                ball.Dispose(); pet.Dispose();
            }
            catch (Exception e) { chk("fatal: " + e, false); }
            try { File.WriteAllText(Path.Combine(Path.GetTempPath(), "buddy_selftest.txt"), sb.ToString()); } catch { }
            return ok ? 0 : 1;
        }
    }
}
