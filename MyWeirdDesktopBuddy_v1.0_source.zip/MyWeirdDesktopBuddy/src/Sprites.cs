using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Reflection;

namespace WeirdBuddy
{
    internal sealed class Anim
    {
        public string Name; public Bitmap Sheet; public int Frames; public float Fps; public bool Loop;
    }

    internal static class Sprites
    {
        public const int Cell = 48;
        public const int BallCell = 16;
        static readonly Dictionary<string, Anim> anims = new Dictionary<string, Anim>();
        public static Bitmap Ball;
        public static Icon AppIcon;
        static readonly ImageAttributes attrs = MakeAttrs();

        static ImageAttributes MakeAttrs() { var a = new ImageAttributes(); a.SetWrapMode(WrapMode.TileFlipXY); return a; }

        public static Anim Get(string name) { return anims[name]; }

        public static void Load()
        {
            var asm = Assembly.GetExecutingAssembly();
            using (var s = asm.GetManifestResourceStream("anims.txt"))
            using (var r = new StreamReader(s))
            {
                string line;
                while ((line = r.ReadLine()) != null)
                {
                    line = line.Trim();
                    if (line.Length == 0 || line[0] == '#') continue;
                    var p = line.Split(' ');
                    var a = new Anim { Name = p[0], Fps = float.Parse(p[1], CultureInfo.InvariantCulture), Loop = p[2] == "1" };
                    a.Sheet = LoadPng(asm, a.Name + ".png");
                    a.Frames = Math.Max(1, a.Sheet.Width / Cell);
                    anims[a.Name] = a;
                }
            }
            Ball = LoadPng(asm, "ball.png");
            using (var s = asm.GetManifestResourceStream("app.ico")) AppIcon = new Icon(s);
        }

        static Bitmap LoadPng(Assembly asm, string name)
        {
            using (var s = asm.GetManifestResourceStream(name))
            {
                if (s == null) throw new FileNotFoundException("Missing embedded resource: " + name);
                using (var tmp = new Bitmap(s))
                {
                    var bmp = new Bitmap(tmp.Width, tmp.Height, PixelFormat.Format32bppPArgb);
                    using (var g = Graphics.FromImage(bmp))
                    {
                        g.CompositingMode = CompositingMode.SourceCopy;
                        g.DrawImage(tmp, 0, 0, tmp.Width, tmp.Height);
                    }
                    return bmp;
                }
            }
        }

        public static void Draw(Graphics g, Bitmap sheet, int cell, int frame, int x, int y, int scale, bool flip)
        {
            var src = new Rectangle(frame * cell, 0, cell, cell);
            int sz = cell * scale;
            if (!flip)
                g.DrawImage(sheet, new Rectangle(x, y, sz, sz), src.X, src.Y, src.Width, src.Height, GraphicsUnit.Pixel, attrs);
            else
                g.DrawImage(sheet, new Point[] { new Point(x + sz, y), new Point(x, y), new Point(x + sz, y + sz) }, src, GraphicsUnit.Pixel, attrs);
        }
    }
}
