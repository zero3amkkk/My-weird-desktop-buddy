using System;
using System.Drawing;
using System.Windows.Forms;

namespace WeirdBuddy
{
    internal sealed class SettingsForm : Form
    {
        readonly AppSettings cfg; readonly Action apply; bool loading;
        TrackBar tbSpeed, tbSize, tbRand; CheckBox cbMsg, cbAuto, cbStart; Label lSpeed, lSize, lRand;

        public SettingsForm(AppSettings c, Action onApply)
        {
            cfg = c; apply = onApply;
            Text = "إعدادات My Weird Desktop Buddy";
            RightToLeft = RightToLeft.Yes;
            Font = new Font("Segoe UI", 10f);
            FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;
            StartPosition = FormStartPosition.CenterScreen; TopMost = true; ShowInTaskbar = true;
            ClientSize = new Size(430, 430);
            Icon = (Icon)Sprites.AppIcon.Clone();

            var flow = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false, Padding = new Padding(16), AutoScroll = false };
            Controls.Add(flow);

            lSpeed = new Label { AutoSize = true, Margin = new Padding(0, 6, 0, 0) };
            tbSpeed = new TrackBar { Minimum = 5, Maximum = 20, TickFrequency = 5, Width = 390 };
            lSize = new Label { AutoSize = true, Margin = new Padding(0, 10, 0, 0) };
            tbSize = new TrackBar { Minimum = 2, Maximum = 6, TickFrequency = 1, Width = 390 };
            lRand = new Label { AutoSize = true, Margin = new Padding(0, 10, 0, 0) };
            tbRand = new TrackBar { Minimum = 0, Maximum = 100, TickFrequency = 10, Width = 390 };
            cbMsg = new CheckBox { Text = "تشغيل الرسائل العشوائية", AutoSize = true, Margin = new Padding(0, 14, 0, 0) };
            cbAuto = new CheckBox { Text = "تشغيل الحركة التلقائية (المشي والجري)", AutoSize = true, Margin = new Padding(0, 8, 0, 0) };
            cbStart = new CheckBox { Text = "تشغيل البرنامج مع بدء تشغيل ويندوز", AutoSize = true, Margin = new Padding(0, 8, 0, 0) };
            var btnReset = new Button { Text = "إعادة الإعدادات للوضع الافتراضي", AutoSize = true, Margin = new Padding(0, 18, 0, 0) };
            var btnClose = new Button { Text = "إغلاق", AutoSize = true, Margin = new Padding(0, 8, 0, 0) };

            flow.Controls.AddRange(new Control[] { lSpeed, tbSpeed, lSize, tbSize, lRand, tbRand, cbMsg, cbAuto, cbStart, btnReset, btnClose });

            LoadFromCfg();
            EventHandler changed = (s, e) => { if (loading) return; ReadToCfg(); UpdateLabels(); apply(); };
            tbSpeed.ValueChanged += changed; tbSize.ValueChanged += changed; tbRand.ValueChanged += changed;
            cbMsg.CheckedChanged += changed; cbAuto.CheckedChanged += changed; cbStart.CheckedChanged += changed;
            btnReset.Click += (s, e) => { cfg.ResetDefaults(); LoadFromCfg(); apply(); };
            btnClose.Click += (s, e) => Close();
        }

        void LoadFromCfg()
        {
            loading = true;
            tbSpeed.Value = Math.Min(20, Math.Max(5, (int)Math.Round(cfg.Speed * 10)));
            tbSize.Value = Math.Min(6, Math.Max(2, cfg.Scale));
            tbRand.Value = Math.Min(100, Math.Max(0, cfg.Randomness));
            cbMsg.Checked = cfg.MessagesEnabled; cbAuto.Checked = cfg.AutoMove; cbStart.Checked = cfg.RunAtStartup;
            UpdateLabels();
            loading = false;
        }

        void ReadToCfg()
        {
            cfg.Speed = tbSpeed.Value / 10.0; cfg.Scale = tbSize.Value; cfg.Randomness = tbRand.Value;
            cfg.MessagesEnabled = cbMsg.Checked; cfg.AutoMove = cbAuto.Checked; cfg.RunAtStartup = cbStart.Checked;
        }

        void UpdateLabels()
        {
            lSpeed.Text = "سرعة حركة الشخصية: " + (tbSpeed.Value / 10.0).ToString("0.0", System.Globalization.CultureInfo.InvariantCulture) + "x";
            lSize.Text = "حجم الشخصية: " + tbSize.Value;
            lRand.Text = "مستوى عشوائية الحركات: " + tbRand.Value + "%";
        }
    }
}
