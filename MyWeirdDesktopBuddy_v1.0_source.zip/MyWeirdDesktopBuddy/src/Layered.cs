using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace WeirdBuddy
{
    internal static class Dpi
    {
        static int factor;
        public static int Factor
        {
            get
            {
                if (factor == 0)
                {
                    try { using (var g = Graphics.FromHwnd(IntPtr.Zero)) factor = Math.Max(1, (int)Math.Round(g.DpiX / 96.0)); }
                    catch { factor = 1; }
                }
                return factor;
            }
        }
    }

    /// <summary>A 32-bit premultiplied-alpha DIB section wrapped by a GDI+ Bitmap, pushed to a layered window.</summary>
    internal sealed class Surface : IDisposable
    {
        public Bitmap Bmp; public Graphics G; public int W, H;
        IntPtr memDc, dib, oldObj, bits;

        public Surface(int w, int h)
        {
            W = w; H = h;
            IntPtr screen = Native.GetDC(IntPtr.Zero);
            try
            {
                memDc = Native.CreateCompatibleDC(screen);
                var bi = new Native.BITMAPINFO();
                bi.bmiHeader.biSize = Marshal.SizeOf(typeof(Native.BITMAPINFOHEADER));
                bi.bmiHeader.biWidth = w; bi.bmiHeader.biHeight = -h; bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = 0;
                dib = Native.CreateDIBSection(screen, ref bi, 0, out bits, IntPtr.Zero, 0);
            }
            finally { Native.ReleaseDC(IntPtr.Zero, screen); }
            if (dib == IntPtr.Zero) throw new InvalidOperationException("CreateDIBSection failed");
            oldObj = Native.SelectObject(memDc, dib);
            Bmp = new Bitmap(w, h, w * 4, PixelFormat.Format32bppPArgb, bits);
            G = Graphics.FromImage(Bmp);
        }

        public void Push(IntPtr hwnd, int x, int y)
        {
            var dst = new Native.POINT(x, y); var size = new Native.SIZE(W, H); var src = new Native.POINT(0, 0);
            var bf = new Native.BLENDFUNCTION { BlendOp = 0, BlendFlags = 0, SourceConstantAlpha = 255, AlphaFormat = 1 };
            Native.UpdateLayeredWindow(hwnd, IntPtr.Zero, ref dst, ref size, memDc, ref src, 0, ref bf, Native.ULW_ALPHA);
        }

        public void Dispose()
        {
            if (G != null) { G.Dispose(); G = null; }
            if (Bmp != null) { Bmp.Dispose(); Bmp = null; }
            if (memDc != IntPtr.Zero) { Native.SelectObject(memDc, oldObj); Native.DeleteObject(dib); Native.DeleteDC(memDc); memDc = IntPtr.Zero; }
        }
    }

    /// <summary>Borderless, topmost, non-activating, per-pixel-alpha window. Fully transparent pixels are click-through.</summary>
    internal class LayeredForm : Form
    {
        public LayeredForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            TopMost = true;
        }
        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ExStyle |= Native.WS_EX_LAYERED | Native.WS_EX_TOOLWINDOW | Native.WS_EX_TOPMOST | Native.WS_EX_NOACTIVATE;
                return cp;
            }
        }
        protected override bool ShowWithoutActivation { get { return true; } }
        public void Reassert()
        {
            if (IsHandleCreated && Visible)
                Native.SetWindowPos(Handle, Native.HWND_TOPMOST, 0, 0, 0, 0, Native.SWP_NOMOVE | Native.SWP_NOSIZE | Native.SWP_NOACTIVATE);
        }
    }
}
